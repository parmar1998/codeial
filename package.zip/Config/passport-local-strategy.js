
const passport=require('passport');

const LocalStrategy=require('passport-local').Strategy;

const User=require("../Models/users")

//authentication using passport
 passport.use(new LocalStrategy({
    usernameField: 'email',
},
    //done here is a callback function which 1 or 2 values
    // async function (email, password, done) {
    //     //find a user and establish the identity
    //     let user = await User.findOne({ email: email });
    //     if (!user || user.password != password) {
    //         console.log('invalid Username Password');
    //         return done(null, false);//error as null and authentication as false
    //     }
    //     return done(null, user);

    // }

    function ( email, password, done) {
        // find a user and establish the identity
        console.log("Inside passportjs");
        User.findOne({ email: email }, function (err, user) {
            if (err) {
                // req.flash('error', err);
                console.log('Error in finding user --> Passport');
                return done(err);
            }

            if (!user || user.password != password) {
                // req.flash('error', 'Invalid Username/ Password');
                console.log('Invalid Username/Password');
                return done(null, false);
            }

            return done(null, user);
        })
    }
));

//serializing the user to decide which key is to be kept in the cookies
passport.serializeUser(function(user,done){
    console.log("userid=",user.id);
    done(null,user.id)
});

//desrializing the user from key in the cookies
passport.deserializeUser(
    async function (id, done) {
        let userbyid = await User.findById(id);
        return done(null, userbyid);
    });
    
module.exports=passport;